import React from "react";
import logo from '../assets/logo1.png';
const InvoiceLayout = ({ invoice }) => {
    const items = invoice?.items?.length
        ? invoice.items
        : [
            {
                serviceDescription: invoice?.serviceDescription,
                qty: invoice?.qty || 1,
                amount: invoice?.amount,
                taxPercent: invoice?.tax,
                tax: invoice?.tax,
                totalAmount: invoice?.totalAmount,
            },
        ];
    invoice = { ...invoice, items };
    return (
        <div className="p-4 w-full max-w-3xl mx-auto border border-gray-200 h-auto rounded-lg shadow">
            {/* Header */}
            <div className=" flex flex-col items-center justify-center">
                <div className="flex items-center space-x-1  space-y-1">
                    <img src={logo} alt="Logo" className="w-30 h-16" />
                    <h1 className="text-3xl text-blue-950 uppercase font-bold italic mt-7">Humtek Solution</h1>
                </div>
                <div className="h-1 w-full bg-blue-950"></div>
            </div>

            {/* Bank Info */}
            <div className=" flex flex-wrap justify-between  w-full h-60 ">
                <div className="w-[50%] space-y-3">
                    {/* <span className="italic font-normal ">M/S </span> */}
                    <div className="flex">
                        {/* <span className="italic font-semibold ">Bank Name : </span> */}
                        <p className=" font-semibold italic ml-1 mt-5  text-blue-950">{invoice?.bankName || "-"} <br />
                            <span className="text-gray-800 font-normal">Gulshan-e-Iqbal Block-1</span>
                        </p>
                    </div>
                    <div className="flex">
                        <p className="font-semibold text-blue-950">Branch Code :</p>
                        <p className="underline ml-1">{invoice?.branchCode || "-"}</p>
                    </div>
                    <div className="text-blue-950">
                        <span className="font-semibold italic">Invoice to : {invoice?.branch || "-"}</span>
                        <p className=" italic text-sm">
                            Dubai Islami bank Adminstration Division Karachi
                        </p>
                    </div>
                    <div className="flex items-center ">
                        <p className=" underline text-blue-950 font-semibold"> Service Type:</p>
                        <span className="ml-3 text-cyan-600"> {invoice?.serviceType || "-"}</span>
                    </div>
                    <div>
                        <h6>NTN # : {invoice?.ntnNumber || "109389"}</h6>
                    </div>
                </div>

                <div className="w-[50%] pl-4 pt-4  space-y-5">
                    <div className="flex  items-center ">
                        <p className=" underline text-blue-950 font-semibold">Invoice NO </p>
                        <span className="ml-6 text-cyan-600"> 00{invoice?.id}</span>
                    </div>
                    <div className="flex items-center ">
                        <p className=" underline text-blue-950 font-semibold"> Model: </p>
                        <span className="ml-14 text-cyan-600"> {invoice?.product || "-"}</span>
                    </div>
                    <div className="flex items-center ">
                        <p className=" underline text-blue-950 font-semibold">Service Date</p>
                        <p className="ml-3 text-cyan-600">{invoice?.serviceDate || "-"}</p>
                    </div>
                    <div className="flex items-center ">
                        <p className=" underline text-blue-950 font-semibold">Invoice Date:</p>
                        <p className="ml-3 text-cyan-600">{invoice?.invoiceDate || "-"}</p>
                    </div>
                    <div>
                        <h6>NTN # : <span className="text-cyan-600 ml-12">9731807-8</span> </h6>
                    </div>
                </div>
            </div>

            {/* Amounts */}

            <div className="mb-4 mt-10">
                <h1 className="text-center font-[impact] text-2xl w-full border-b-2 border-blue-950 text-gray-500">
                    SALES TAX INVOICE
                </h1>
                <table
                    style={{
                        borderCollapse: 'collapse',
                        width: '100%',
                        border: '1px solid black'
                    }}
                    className="w-full text-center "
                >
                    <thead>
                        <tr className="bg-blue-950 text-white p-2">
                            <th style={{ padding: '8px' }} >Sr</th>
                            <th style={{ padding: '8px' }}>Description</th>
                            <th style={{ padding: '8px' }}>Qty</th>
                            <th style={{ padding: '8px' }}>Unit Price</th>
                            <th style={{ padding: '8px' }}>%</th>
                            <th style={{ padding: '8px' }}>Tax</th>
                            <th style={{ padding: '8px' }}>Total Price</th>
                        </tr>
                    </thead>
                    <tbody className="min-h-80">
                        {(invoice?.items || []).map((item, index) => (
                            <tr key={index}>
                                {console.log("INVOICE:", invoice)}
                                <td className="px-2 py-5  border-r-2 border-black">
                                    {index + 1}
                                </td>

                                <td className="px-2 text-start py-5 border-r-2 border-black capitalize">
                                    {item?.serviceDescription || "N/A"}
                                </td>

                                <td className="px-2 py-5  border-r-2 border-black">
                                    {item?.qty || 1}
                                </td>

                                <td className="px-2 py-5  border-r-2 border-black">
                                    {item?.amount?.toLocaleString() || 0}
                                </td>

                                <td className="px-2 py-5  border-r-2 border-black">
                                    {item?.taxPercent || 0}
                                </td>

                                <td className="px-2 py-5  border-r-2 border-black">
                                    {item?.tax?.toLocaleString() || 0}
                                </td>

                                <td className="px-2 text-end py-5 border-r-2 border-black bg-cyan-100 font-semibold">
                                    {item?.totalAmount?.toLocaleString() || 0}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="flex justify-between border-t mt-0.5">
                    <div className="flex  w-[40%] space-y-1 p-2">
                        <p className="font-semibold">Status : </p>
                        <p className="ml-1 text-amber-700">{invoice?.status || "Pending"}</p>
                    </div>
                    <div className="w-[29%] border flex justify-end flex-col bg-blue-50">
                        <div className="border w-full">
                            <div className="flex items-center justify-between ">
                                <span className="font-bold p-1">Sub Total : </span>
                                <span className=" px-0.5">
                                    {invoice?.items?.reduce((sum, item) => sum + (item?.totalAmount || 0), 0)?.toLocaleString() || 0}
                                </span>
                            </div>
                        </div>
                        <div className="border w-full my-0.5">
                            <div className="flex items-center justify-between">
                                <span className="font-bold p-1">Discount : </span>
                                <span className=" px-0.5">
                                    {invoice?.discount?.toLocaleString() || ""}
                                </span>
                            </div>
                        </div>
                        <div className="border w-full mb-0.5">
                            <div className="flex items-center justify-between">
                                <span className="font-bold p-1">Grand Total : </span>
                                <span className=" px-0.5">
                                    {invoice?.items?.reduce((sum, item) => sum + (item?.totalAmount || 0), 0)?.toLocaleString() || 0}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex items-center -mt-6">
                    <div className="w-[50%]">
                        <div className="flex items-end border-b-2 border-gray-800">
                            <h1 className="text-3xl text-blue-950 uppercase font-bold italic">Humtek Solutions</h1>
                            <img src={logo} className="w-15 h-15" alt="" />
                        </div>
                        <div className="border-t border-gray-800 ">
                            <p className="p-1 text-blue-950 font-bold -mt-1.5">Email: <span className="border-b font-medium italic text-blue-900 "> Muhammad.amir@humtek.com.pk </span></p>
                        </div>
                    </div>
                    <div className="text-start text-blue-950 ml-3 italic font-semibold">
                        Contact.+92301-6783656
                    </div>
                </div>
                <div className="flex justify-between mt-15">
                    <p className="text-blue-950 border-b-2 italic font-semibold ">Customer's Receiver</p>
                    <p className="text-blue-950 border-b-2 italic font-semibold" >Authorized Signatory</p>
                </div>

                <h1 className="text-blue-950 font-bold text-3xl text-center mt-10">A-396,BLOCK-7, K.A.E.C.H.S, KARACHI</h1>
            </div>
        </div>
    );
};

export default InvoiceLayout;